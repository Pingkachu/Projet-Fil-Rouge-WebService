//
//  ModifyAnnonce.swift
//  JSon
//
//  Created by Matthieu Hannequin on 12/04/2016.
//  Copyright © 2016 AkbarDevCenter. All rights reserved.
//

import Foundation
import UIKit

class ModifyAnnonce: UIViewController {
    
    @IBOutlet var modeleAnnonce : UITextField!
    @IBOutlet var marqueAnnonce : UITextField!
    @IBOutlet var prixAnnonce : UITextField!
    var id_annonce = String()
    //@IBOutlet var buttonValider : UIButton!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
 
    }
    
    // Do any additional setup after loading the view, typically from a nib.
    
    /*     func downloadEnd(data : NSData?, reponse : NSURLResponse?, error: NSError?)
    {
    guard let data = data where error == nil else
    {
    return
    }
    
    print("Fetch ok")
    }
    */
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func validerPut(sender : UIButton)
    {
        self.response(CommonFunc.put(modeleAnnonce.text!, marque: marqueAnnonce.text!, prix: prixAnnonce.text!, id: id_annonce))
    }
    
    func response(response : Bool)
    {
        var refreshAlert = UIAlertController()
        if(response)
        {
            refreshAlert = UIAlertController(title: "Succès !", message: "Vous avez bien modifié cette annonce.", preferredStyle: UIAlertControllerStyle.Alert)
        } else {
            refreshAlert = UIAlertController(title: "Erreur", message: "Désole, nous n'avons pas pu modifier cette annonce.", preferredStyle: UIAlertControllerStyle.Alert)
        }
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .Default, handler: { (action: UIAlertAction!) in
        }))
        
        presentViewController(refreshAlert, animated: true, completion: nil)
    }
}
