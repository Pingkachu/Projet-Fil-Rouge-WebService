//
//  Constants.swift
//  JSon
//
//  Created by etudiant on 09/03/2016.
//  Copyright © 2016 AkbarDevCenter. All rights reserved.
//

import Foundation

class Constants {
    static let KeyId_annonce = "id_annonce"
    static let KeyImage = "image"
    static let KeyMarque = "marque"
    static let KeyModele = "modele"
    static let KeyPrix = "prix"
    static let KeyEtat = "etat"
    static let KeyTelephone = "telephone"
    static let KeyCommentaire = "commentaire"
    static let KeyDate_annonce = "date_annonce"
    static let KeyId_membre = "id_membre"

}

class URL
{
    static let jsonUrl = "http://filrouge.pierrrec.com/annonces.php?start=0&end=8"
    static let annonceUrl = "http://filrouge.pierrrec.com/annonce.php"
    static let annoncesUrl = "http://filrouge.pierrrec.com/annonces.php"
}