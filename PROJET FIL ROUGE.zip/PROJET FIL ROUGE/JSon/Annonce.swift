//
//  Annonce.swift
//  JSon
//
//  Created by etudiant on 08/03/2016.
//  Copyright © 2016 AkbarDevCenter. All rights reserved.
//

import UIKit

class Annonce: NSObject, NSCoding {
    
    private static let DocumentsDirectory = NSFileManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).first!
    
    private static let ArchiveURL = DocumentsDirectory.URLByAppendingPathComponent("liste")
    
    static var list = [Annonce]()
    
    var id_annonce = String()
    var image = String()
    var marque = String()
    var modele = String()
    var prix = String()
    var etat = String()
    var telephone = String()
    var commentaire = String()
    var date_annonce = String()
    var id_membre = String()
    
    override init() {
        
        super.init()
    }
    

    
    class func parseJSON(data : NSData)
    {
        do
        {
            let root = try NSJSONSerialization.JSONObjectWithData(data, options: .AllowFragments)

            guard let list = root["annonce"] as?  [AnyObject] else
            {
                return
            }
            
            Annonce.list.removeAll()
            
            for item in list
            {
                let annonce = Annonce()
                
                if let id_annonce = item[Constants.KeyId_annonce] as? String
                {
                    annonce.id_annonce = id_annonce
                }
                
                if let image = item[Constants.KeyImage] as? String
                {
                    annonce.image = image
                }
                
                if let tel = item[Constants.KeyTelephone] as? String
                {
                    annonce.telephone = "0\(tel)"
                }
                
                if let marq = item[Constants.KeyMarque] as? String
                {
                    annonce.marque = marq
                }
                
                if let model = item[Constants.KeyModele] as? String
                {
                    annonce.modele = model
                }
                
                if let price = item[Constants.KeyPrix] as? String
                {
                    annonce.prix = price
                }
                
                if let state = item[Constants.KeyEtat] as? String
                {
                    annonce.etat = state
                }
                
                if let comment = item[Constants.KeyCommentaire] as? String
                {
                    annonce.commentaire = comment
                }
                
                
                if let date_annonx = item[Constants.KeyDate_annonce] as? String
                {
                    annonce.date_annonce = date_annonx
                    
                }
                
                if let idMembre = item[Constants.KeyId_membre] as? String
                {
                    annonce.id_membre = idMembre
                }
                
                Annonce.list.append(annonce)
            }
            
            saveData()
            
            for annonce in Annonce.list
            {
                print("id_annonce :", annonce.id_annonce)
                print("Lien de l'image :", annonce.image)
                print("marque : ", annonce.marque)
                print("Modele :", annonce.modele)
                print("Prix du téléphone :", annonce.prix, "euros")
                print("Etat du téléphone :", annonce.etat)
                print("Téléphone du propriétaire:", annonce.telephone)
                print("commentaire :", annonce.commentaire)
                print("Ajouté le :", annonce.date_annonce)
                print("Identifiant du propriétaire :", annonce.id_membre)
                print("#################################################")
                print("")
            }
            
        }
        catch
        {
            return
        }
    }
    
    func encodeWithCoder(aCoder: NSCoder)
    {
        aCoder.encodeObject(id_annonce, forKey : "idAnnonce")
        aCoder.encodeObject(modele, forKey : "model")
        aCoder.encodeObject(prix, forKey: "price")
        //dupliquer pour chaque
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        //dupliquer pour chaque
       if let idAnnonce = aDecoder.decodeObjectForKey("idAnnonce") as? String
       {
            id_annonce = idAnnonce
        }
        
        if let mdl = aDecoder.decodeObjectForKey("model") as? String
        {
            modele = mdl
        }
        
        if let priceA = aDecoder.decodeObjectForKey("price") as? String
        {
            prix = priceA
        }
    }
    
        class func saveData() -> Bool
        {
            print("Save to \(ArchiveURL.path!)")
           return  NSKeyedArchiver.archiveRootObject(list, toFile: ArchiveURL.path!)// list = liste d'annonce list = [Annonce]()
        }
        
        class func loadData()
        {
            print("Load \(ArchiveURL.path!)")
            if let tempList = NSKeyedUnarchiver.unarchiveObjectWithFile(ArchiveURL.path!) as? [Annonce]
            {
                Annonce.list = tempList
            }
        
    }
    

}
