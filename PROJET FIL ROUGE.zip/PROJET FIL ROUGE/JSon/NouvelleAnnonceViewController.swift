//
//  NouvelleAnnonceViewController.swift
//  JSon
//
//  Created by etudiant on 10/03/2016.
//  Copyright © 2016 AkbarDevCenter. All rights reserved.
//

import UIKit

class NouvelleAnnonceViewController: UIViewController {
    
    @IBOutlet var commAnnonce : UITextField!
    @IBOutlet var modeleAnnonce : UITextField!
    @IBOutlet var marqueAnnonce : UITextField!
    @IBOutlet var prixAnnonce : UITextField!
    @IBOutlet var etatAnnonce : UITextField!
    @IBOutlet var telAnnonce : UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func validerPost(sender : UIButton)
    {
        var data = ["com" : commAnnonce.text!, "modele" : modeleAnnonce.text!, "marque" : marqueAnnonce.text!, "prix" : prixAnnonce.text!, "tel" : telAnnonce.text!, "etat" : etatAnnonce.text!]
        self.response(CommonFunc.postRequest(data))
    }
    
    func response(response : Bool)
    {
        var refreshAlert = UIAlertController()
        if(response)
        {
            refreshAlert = UIAlertController(title: "Bravo !", message: "Vous avez bien créer cette annonce.", preferredStyle: UIAlertControllerStyle.Alert)
        } else {
            refreshAlert = UIAlertController(title: "Erreur", message: "Désole, nous n'avons pas pu créer votre annonce.", preferredStyle: UIAlertControllerStyle.Alert)
        }
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .Default, handler: { (action: UIAlertAction!) in
        }))
        
        presentViewController(refreshAlert, animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
