//
//  DownloadImage.swift
//  JSon
//
//  Created by Matthieu Hannequin on 11/04/2016.
//  Copyright © 2016 AkbarDevCenter. All rights reserved.
//

import Foundation
import UIKit

class CommonFunc {
    
    class func downloadImage(url : String, content : UIImageView) -> Bool
    {
        if let urlImage = NSURL(string: url)
        {
            let task = NSURLSession.sharedSession().dataTaskWithURL(urlImage)
                {
                    (data, response, error) -> Void in
                    guard let data = data where error == nil else
                    {
                        print("Erreur de téléchargement \(error?.code)")
                        
                        return
                    }
                    
                    if  let img = UIImage(data : data)
                    {
                        dispatch_async(dispatch_get_main_queue(), { () -> Void in
                            content.image = img
                        })
                        
                    }
                    
                    print("Fetch ok")
            }
            task.resume()
            return true
        }
        return false
    }
    
    class func delete(id : String) ->Bool
    {
        let url:NSURL = NSURL(string: URL.annonceUrl)!
        
        let request = NSMutableURLRequest(URL: url)
        request.HTTPMethod = "DELETE"
        request.cachePolicy = NSURLRequestCachePolicy.ReloadIgnoringCacheData
        
        let paramString = "id_annonce=\(id)"
        request.HTTPBody = paramString.dataUsingEncoding( NSUTF8StringEncoding )
        var header : Bool = false
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request)
            { (data, response, error) -> Void in
                guard let data = data where error == nil else
                {
                    print("error")
                    return
                }
                
                if let echo = NSString (data: data, encoding: NSUTF8StringEncoding) as? String
                {
                    print("Requete ok \(echo)")
                    if ((echo.rangeOfString("200",
                        options: NSStringCompareOptions.BackwardsSearch)) != nil)
                    {
                        header = true
                    }
                    else
                    {
                        header = false
                    }
                }
                
                
            }
        task.resume();
        return header;
    }
    
    class func put(modele : String, marque : String, prix : String, id : String) ->Bool
    {
        let url:NSURL = NSURL(string: URL.annonceUrl)!
        
        let request = NSMutableURLRequest(URL: url)
        request.HTTPMethod = "PUT"
        request.cachePolicy = NSURLRequestCachePolicy.ReloadIgnoringCacheData
        
        let paramString = "id_annonce=\(id)&modele=\(modele)&marque=\(marque)&prix=\(prix)"
        request.HTTPBody = paramString.dataUsingEncoding( NSUTF8StringEncoding )
        var header : Bool = false
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request)
            { (data, response, error) -> Void in
                guard let data = data where error == nil else
                {
                    print("error")
                    return
                }
                
                if let echo = NSString (data: data, encoding: NSUTF8StringEncoding) as? String
                {
                    print("Requete ok \(echo)")
                    if ((echo.rangeOfString("200",
                        options: NSStringCompareOptions.BackwardsSearch)) != nil)
                    {
                        header = true
                    }
                    else
                    {
                        header = false
                    }
                }
                
                
        }
        task.resume();
        return header;
    }
    
    class func postRequest( data : [String : String] )->Bool
    {
        let url:NSURL = NSURL(string: URL.annoncesUrl)!
        
        let request = NSMutableURLRequest(URL: url)
        request.HTTPMethod = "POST"
        request.cachePolicy = NSURLRequestCachePolicy.ReloadIgnoringCacheData
        
        //        let data = "hello"
        let paramString = "marque=\(data["marque"])&modele=\(data["modele"])&etat=\(data["etat"])&prix=\(data["prix"])&tel=\(data["tel"])&com=\(data["com"])"
        request.HTTPBody = paramString.dataUsingEncoding( NSUTF8StringEncoding )
        
        var header : Bool = false
        
        let task = NSURLSession.sharedSession().dataTaskWithRequest(request)
            { (data, response, error) -> Void in
                guard let data = data where error == nil else
                {
                    print("error")
                    return
                }
                
                if let echo = NSString (data: data, encoding: NSUTF8StringEncoding) as? String
                {
                    print("Requete ok \(echo)")
                    if ((echo.rangeOfString("200",
                        options: NSStringCompareOptions.BackwardsSearch)) != nil)
                    {
                        header = true
                    }
                    else
                    {
                        header = false
                    }
                }
                
                
        }
        task.resume();
        return header;
    }
    
}