//
//  ViewController.swift
//  JSon
//
//  Created by etudiant on 07/03/2016.
//  Copyright © 2016 AkbarDevCenter. All rights reserved.
//

import UIKit

class SingleAnnonceController: UIViewController {
    
    var index : Int = -1
    
    var refreshAlert = UIAlertController()
   
    @IBOutlet var labelName : UILabel!
    
    @IBOutlet var labelAnnonce : UILabel!
    
    @IBOutlet var commAnnonce : UILabel!
    @IBOutlet var imageAnnonce : UIImageView!
    @IBOutlet var modeleAnnonce : UILabel!
    @IBOutlet var marqueAnnonce : UILabel!
    @IBOutlet var prixAnnonce : UILabel!
    @IBOutlet var etatAnnonce : UILabel!
    @IBOutlet var dateAnnonce : UILabel!
    @IBOutlet var avatarAnnonce : UIImageView!
    @IBOutlet var telAnnonce : UILabel!
    
    

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        showData()
        
    }
    
    func showData()
    {
        //On récupère l'annonce grâce à l'index
        let annonce = Annonce.list[index]
        
        //On met les informations dans notre vue
        commAnnonce.text = "Commentaires : \(annonce.commentaire)"
        commAnnonce.numberOfLines = 6
        let imgUrl = annonce.image
        CommonFunc.downloadImage(imgUrl, content: imageAnnonce)
        modeleAnnonce.text = "Modele : \(annonce.modele)"
        prixAnnonce.text = "Prix : \(annonce.prix) €"
        marqueAnnonce.text = "Marque : \(annonce.marque)"
        dateAnnonce.text = "Ajouté le \(annonce.date_annonce)"
        dateAnnonce.numberOfLines = 2
        etatAnnonce.text = "Etat : \(annonce.etat)"
        telAnnonce.text = "Téléphone : \(annonce.telephone)"
        
    }
    
    
        // Do any additional setup after loading the view, typically from a nib.
    
   /*     func downloadEnd(data : NSData?, reponse : NSURLResponse?, error: NSError?)
        {
            guard let data = data where error == nil else
            {
                return
            }
            
            print("Fetch ok")
        }
     */
    
    @IBAction func confirmationMessage()
    {
        refreshAlert = UIAlertController(title: "Confirmation ?", message: "Vous allez supprimer cette annonce.", preferredStyle: UIAlertControllerStyle.Alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .Default, handler: { (action: UIAlertAction!) in
            self.responseMessage(CommonFunc.delete(Annonce.list[self.index].id_annonce))
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .Default, handler: { (action: UIAlertAction!) in
        }))
        
        presentViewController(refreshAlert, animated: true, completion: nil)
    }
    
    func responseMessage(response : Bool)
    {
        if(response)
        {
            refreshAlert = UIAlertController(title: "Réussite !", message: "Vous avez bien supprimé cette annonce.", preferredStyle: UIAlertControllerStyle.Alert)
        } else {
            refreshAlert = UIAlertController(title: "Erreur", message: "Désole, nous n'avons pas pu supprimer cette annonce.", preferredStyle: UIAlertControllerStyle.Alert)
        }
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .Default, handler: { (action: UIAlertAction!) in
        }))
        
        presentViewController(refreshAlert, animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        if let next = segue.destinationViewController as? ModifyAnnonce
        {
            next.id_annonce = Annonce.list[index].id_annonce
        }
        //Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }


}

